using System;
using MoreMountains.Tools;
using Unity.VisualScripting;
using UnityEngine;
using Random = UnityEngine.Random;

public struct FloatPair
{
    public float x;
    public float y;

    public FloatPair(float xValue, float yValue2)
    {
        x = xValue;
        y = yValue2;
    }
}

public abstract class State : IState
{
    protected EnemyAI enemyAI;

    public IState Initialize(EnemyAI p_enemyAI)
    {
        enemyAI = p_enemyAI;
        return this;
    }

    public abstract void Enter();
    public abstract void Execute();
    public abstract void Exit();

    private const float CLIFF_DETECT_DISTANCE = 0.5f;

    protected static int CliffDetect(EnemyAI p_enemyAI) //절벽 감지 함수. 
    {
        int     _layerMask = 1 << LayerMask.NameToLayer("Floor");
        Vector3 _position  = p_enemyAI._transform.position;

        Vector2 _checkPoint = new Vector2(
            _position.x + p_enemyAI._targetDirection.x * p_enemyAI.bodySize.x / 2,
            _position.y - p_enemyAI.bodySize.y                                / 2
        );

        RaycastHit2D _hit = Physics2D.Raycast(_checkPoint, Vector2.down, CLIFF_DETECT_DISTANCE, _layerMask);
        return _hit.collider == null ? 1 : 0;
    }

    /// <summary>
    /// Chase 범위 내에 플레이어가 있는지 확인하고 있다면 제일 가까운 플레이어 반환
    /// </summary>
    protected static (bool, Player) PlayerInRange(EnemyAI p_enemyAI)
    {
        Player[] _players        = GameManager.Instance.GetPlayers();
        Player   _targetPlayer   = null;
        float    _targetDistance = Mathf.Infinity;

        foreach (Player _player in _players)
        {
            float _distance = Vector2.Distance(p_enemyAI._transform.position, _player.transform.position);
            if (!(_distance < _targetDistance)) continue;
            _targetDistance = _distance;
            _targetPlayer   = _player;
        }

        return _targetDistance <= p_enemyAI._base.stats.attackRange ? (true, _targetPlayer) : (false, null);
    }
}

public class SWander : State
{
    private enum WanderState
    {
        Moving,
        Waiting
    }

    private WanderState _currentState;
    private float       _nextMovableTime, _nextWaitTime;
    private float       _nextChangeDirectionTime;

    private readonly FloatPair _randomMovingTime = new FloatPair(3, 5),
                               _randomWaitTime   = new FloatPair(1, 3);

    public override void Enter()
    {
        _currentState = WanderState.Moving;
    }

    public override void Execute()
    {
        //플레이어가 Chase 범위 내에 있는지 확인해서 있으면 Chase 상태로 전환
        (bool _playerInRange, Player _targetPlayer) = PlayerInRange(enemyAI);
        if (_playerInRange)
        {
            enemyAI._targetPlayer = _targetPlayer;
            enemyAI.CurrentState  = enemyAI.States["Chase"];
            return;
        }

        //----------------------------------------------

        switch (_currentState)
        {
            case WanderState.Moving:
                if (Time.time >= _nextMovableTime)
                {
                    //Waiting 상태로 진입하고 다시 Move 상태로 진입할 시간을 랜덤으로 설정
                    _nextMovableTime = Time.time + Random.Range(_randomWaitTime.x, _randomWaitTime.y);
                    _currentState    = WanderState.Waiting;
                }

                if (CliffDetect(enemyAI) == 1)
                    enemyAI._targetDirection.InvertX(); //절벽 감지시 방향 반전

                break;

            case WanderState.Waiting:
                if (Time.time >= _nextWaitTime)
                {
                    //Move 상태로 진입하고 다시 Waiting 상태로 진입할 시간을 랜덤으로 설정
                    _nextWaitTime = Time.time + Random.Range(_randomMovingTime.x, _randomMovingTime.y);
                    _currentState = WanderState.Moving;
                }

                break;
            default:
                throw new ArgumentOutOfRangeException();
        }
    }

    public override void Exit()
    {
        throw new System.NotImplementedException();
    }
}

public class SChase : State
{
    public override void Enter()
    {
        throw new System.NotImplementedException();
    }

    public override void Execute()
    {
        throw new System.NotImplementedException();
    }

    public override void Exit()
    {
        throw new System.NotImplementedException();
    }
}

public class SAttack : State
{
    public override void Enter()
    {
        throw new System.NotImplementedException();
    }

    public override void Execute()
    {
        throw new System.NotImplementedException();
    }

    public override void Exit()
    {
        throw new System.NotImplementedException();
    }
}